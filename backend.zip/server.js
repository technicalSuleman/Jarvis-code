const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { exec } = require("child_process");
const { normalize } = require("path");
const app = express();
const port = process.env.PORT || 5000;

app.use(bodyParser.json());
app.use(
  cors({
    origin: "http://localhost:5173",
  })
);

const execCommand = (command) => {
  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error(`Exec error: ${error.message}`);
      return;
    }
    if (stderr) {
      console.error(`Stderr: ${stderr}`);
      return;
    }
    console.log(`Stdout: ${stdout}`);
  });
};

app.post("/chat", (req, res) => {
  const userMessage = req.body.message;
  let botResponse = userMessage;

  if (
    userMessage === "Can you hear me?" ||
    userMessage === "Can you listen me?"
  ) {
    botResponse = "Yes, I hear you. What do you want...";
  } else if (
    userMessage === "open youtube" ||
    userMessage === "Open YouTube."
  ) {
    botResponse = "Opening YouTube...";
    execCommand("start chrome https://www.youtube.com");
  } else if (
    userMessage === "open calculator" ||
    userMessage === "Open calculator."
  ) {
    botResponse = "Opening calculator...";
    execCommand("calc");
  } else if (userMessage === "Open Chrome." || userMessage === "open chrome.") {
    botResponse = "You want to open Google Chrome...";
    execCommand("start chrome");
  } else if (
    userMessage === "Open Facebook." ||
    userMessage === "open facebook."
  ) {
    botResponse = "Opening Facebook...";
    execCommand("start chrome https://www.facebook.com");
  } else if (userMessage === "Open Google Classroom.") {
    botResponse = "Opening Google Classroom...";
    execCommand("start chrome https://classroom.google.com/");
  } else if (userMessage === "Open Instagram.") {
    botResponse = "Opening Instagram";
    execCommand("start chrome https://www.instagram.com/");
  } else if (userMessage === "Open WhatsApp.") {
    botResponse = "Opening WhatsApp...";
    execCommand("start chrome https://web.whatsapp.com/");
  } else if (userMessage === "Open Bootstrap.") {
    botResponse = "Opening Bootstrap...";
    execCommand(
      "start chrome https://getbootstrap.com/docs/5.3/getting-started/introduction/"
    );
  } else if (
    userMessage === "Open VS Code." ||
    userMessage === "open vs code." ||
    userMessage === "Open Vscode."
  ) {
    botResponse = "Opening Visual Studio Code...";
    execCommand("code");
  } else if (
    userMessage === "Open Sublime Text." ||
    userMessage === "open sublime text."
  ) {
    botResponse = "Opening Sublime Text...";
    execCommand('"C:\\Program Files\\Sublime Text 3\\sublime_text.exe"');
  } else if (
    userMessage === "Open ChatGPT." ||
    userMessage === "Open chat JPD." ||
    userMessage === "Open Cat GPD." ||
    userMessage === "Open chat GBD." ||
    userMessage === "Open chat GPD."
  ) {
    botResponse = "Opening Chat GPT";
    execCommand("start chrome https://chatgpt.com/");
  } else if (userMessage === "Open Spotify.") {
    botResponse = "Opening Spotify.";
    execCommand("start chrome https://open.spotify.com/");
  } else if (userMessage === "Open App Store.") {
    botResponse = "Opening App Store.";
    execCommand("start ms-windows-store://");
  } else if (userMessage === "Open File Explorer.") {
    botResponse = "Opening File Explorer...";
    execCommand("explorer");
  } else if (userMessage === "Open Word.") {
    botResponse = "Opening Microsoft Word...";
    execCommand("start winword");
  } else if (userMessage === "Open PowerPoint.") {
    botResponse = "Opening Microsoft PowerPoint...";
    execCommand("start powerpnt");
  } else if (userMessage === "Open Excel.") {
    botResponse = "Opening Microsoft Excel...";
    execCommand("start excel");
  } else if (userMessage === "Open Visio." || userMessage === "Open video.") {
    botResponse = "Opening Microsoft Visio...";
    execCommand("start visio");
  } else if (userMessage === "Open Notepad.") {
    botResponse = "Opening Notepad...";
    execCommand("notepad");
  } else if (userMessage === "What's your name?") {
    botResponse = "Sir I am Jarvis";
  } else if (userMessage === "How are you?") {
      botResponse = "I am fine. And you?";
  } else if (userMessage === "Good.") {
      botResponse = "Have a nice day";
  } else {
    console.log(` ${userMessage}`);
    botResponse = `${userMessage}`;
  }

  res.json({ response: botResponse });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
